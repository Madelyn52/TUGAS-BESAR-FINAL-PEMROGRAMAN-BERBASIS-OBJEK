/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tubespbo;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author aryah
 */
public class database {
    static Connection conn;
    static Statement stat;
    public static Connection getConnection(){
        if(conn == null){
            try{
                conn = DriverManager.getConnection("jdbc:mysql://localhost/pbo", "root", "");
            }
            catch(SQLException e){
            }
        }
        return conn;
    }
    public static Statement getStatement(){
            if(stat == null){
            try{
                stat = conn.createStatement();
            }
            catch(SQLException e){;
            }
        }
        return stat;
    }
    public void query(String SQLString) {
        try {
            stat.executeUpdate(SQLString);
        } catch(Exception e) {
            
        }
    }
}
